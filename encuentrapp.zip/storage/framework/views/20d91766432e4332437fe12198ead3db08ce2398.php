

<?php $__env->startSection('content'); ?>

<?php echo $__env->make('alerts.success', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<section class="content-header">
  <div class="container-fluid">
    <div class="row mb-2">
      <div class="col-sm-6">
        <h1></h1>
      </div>
      <div class="col-sm-6">
        <ol class="breadcrumb float-sm-right">
          <li class="breadcrumb-item"><a href="#">Inicio</a></li>
          <li class="breadcrumb-item active"></li>
        </ol>
      </div>
    </div>
  </div><!-- /.container-fluid -->
</section>

<section class="content">

<div class="container">


  <div class="card">
     <h5 class="card-header info-color white-text text-center py-4">
         <strong>Servicios</strong>
     </h5>
     <!--Card content-->
     <div class="card-body px-lg-5">
       <table class="table table-borderless">
         <thead>
           <tr>
             <th scope="col">#</th>
             <th scope="col">Foto</th>
             <th scope="col">Nombre</th>
             <th scope="col">Opciones</th>
           </tr>
         </thead>
         <tbody>
           <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <th><?php echo e($service->id); ?></th>
                <th><img src="<?php echo e(asset('storage').'/'.$service->foto); ?>" alt="" width="150"></img></th>
                <th><?php echo e($service->nombre); ?></th>
                <th>
                  <a href="<?php echo e(route ('services.edit', $service->id)); ?>" class="btn btn-info">
                    <i class="fa fa-edit text-white"></i>
                     Editar
                  </a>
                  <button type="button" class="btn btn-danger" data-toggle="modal" data-target="#centralModalDanger<?php echo e($service->id); ?>">
                    <i class="fa fa-trash text-white"></i>
                    Eliminar
                  </button>
                </th>
            </tr>

            <?php echo $__env->make('alerts.modalService', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

         </tbody>
       </table>
     </div>

  </div>
  <!-- Material form subscription -->

  <?php echo $services->links(); ?>


  <br><br>
  </div>

  <div class="fixed-action-btn smooth-scroll" style="bottom: 45px; right: 24px;">
  <a href="<?php echo URL::to('/services/create'); ?>" class="btn-floating  btn-lg red">
    <i class="fa fa-plus"></i>
  </a>
</div>


</section>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\encuentrapp\resources\views/services/admin.blade.php ENDPATH**/ ?>